1. I use the second approach to get databases and tables as TA meantioned on Piazza.
2. I add a custom method in data_table_adaptor, get_db_tables since it is a protected variable in that module.
3. In the extra credit part, if only send limit but not offset, I set the offset be 0 and there is no previous, only next.

PS: I encountered some Internet disconnection when I submited the assignment and I was late for few minutes. I would appreciate if I will be fine. But if it is still counted as late, I use one late day.
